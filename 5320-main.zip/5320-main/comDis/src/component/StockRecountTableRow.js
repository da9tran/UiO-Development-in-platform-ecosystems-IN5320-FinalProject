import React, { useState } from "react";
import classes from "../App.module.css";
import {
  TableRow,
  TableCell,
  FlyoutMenu,
  MenuItem,
  Input,
  DropdownButton,
} from "@dhis2/ui";

export function StockRecountTableRow(props) {
    const [amount, setAmount] = useState(0);
    const [commodity, setCommodity] = useState("Choose commodity");
    const [comID, setcomID] = useState(undefined);

    let onChoice = (id) => {
      let index = (props.commodityData).map(e => e.id).indexOf(id);
      setAmount((props.commodityData[index]).endbalance);
    }

    let onChange = (event) => {
      props.getData(props.id, comID, event.value);
      props.dataSend(props.dataToBeSent);
    }
    
    return (
        <TableRow>
        <TableCell>
        <DropdownButton name="addCommodity" value="buttonValue" component={
            <FlyoutMenu maxHeight="350px">
              {(props.commodityData).map((element) => (
                <MenuItem onClick={() => {
                  setCommodity(element.name);
                  setcomID(element.id);
                  onChoice(element.id);
                }} label={(element.name)}></MenuItem>
              ))}
            </FlyoutMenu>
        }>{commodity}</DropdownButton>

        </TableCell>
        <TableCell>{amount}</TableCell> 
        <TableCell>
          <Input
            className={classes.recountNumberInput}
            dense
            name="recountedInput"
            placeholder="0"
            onChange={event => { onChange(event)} }
          />
        </TableCell>   
      </TableRow>
    )
}