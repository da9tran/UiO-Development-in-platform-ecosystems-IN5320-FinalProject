import React from "react";
import { useDataQuery } from "@dhis2/app-runtime";
import { Menu } from "@dhis2/ui";
import { MenuItem } from "@dhis2/ui";
import { useState } from "react";
import classes from "../App.module.css"
import {
  Table,
  TableBody,
  TableCell,
  TableCellHead,
  TableFoot,
  TableHead,
  TableRow,
  TableRowHead,
} from "@dhis2/ui";

// query for fetching transaction history from our dataStore
const dataQuery = {
  dataSets: {
    resource: "/dataStore/IN5320-G15/transactions",
    params: {
      fields: "transactionType, amount, date, dispensedBy, dispensedTo, commodity[name, id]",
    },
  },
};

function mergeData(data) {
  let mergedData = data.dataSets.dataSets.map((element) => {
    return {
      transactionType: element.transactionType,
      date: element.date,
      dispensedBy: element.dispensedBy,
      dispensedTo: element.dispensedTo,
    };
  });

  return mergedData;
}

export function TransactionHistoryTable() {
  const { loading, error, data } = useDataQuery(dataQuery);
  const [tableElement, setTableElement] = useState();

  if (error) {
    return <span>ERROR: {error.message}</span>;
  }

  if (loading) {
    return <span>Loading...</span>;
  }

  if (data) {
    console.log("API response:", data);
    let mergedData = mergeData(data);

    // console.log("Mergeddata:", mergedData);
    return (
      <div className={classes.transactionHistoryTable}>
        <Table>
          <TableHead>
            <TableRowHead>
              <TableCellHead>Transaction type</TableCellHead>
              <TableCellHead>Dispensed by</TableCellHead>
              <TableCellHead>Recipient</TableCellHead>
              <TableCellHead>Date</TableCellHead>
            </TableRowHead>
          </TableHead>
        {mergedData.map((e) => {
          return (
            <TableBody>
              <TableRow key={e.id}>
                <TableCell>{(e.transactionType)}</TableCell>
                <TableCell>{e.dispensedBy}</TableCell>
                <TableCell>{e.dispensedTo}</TableCell>
                <TableCell>{e.date}</TableCell>
              </TableRow>
            </TableBody>
          );
        })}
        </Table>
      </div>
    );
  }
}
