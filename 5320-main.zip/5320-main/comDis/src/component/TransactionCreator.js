import React from "react";
import { useDataQuery } from "@dhis2/app-runtime";
import { useDataMutation } from "@dhis2/app-runtime";


export function TransactionCreator(props){
    let dispensedby = props.dispensedby;
    let recipient = props.recipient;
    let date = props.date;
    let type = props.type;

    const transactionRequest = {
        request0: {
            resource: "dataStore/IN5320-G15/transactions"
        }
    }

    const sendTransactionRequest = () => {
        const { loading, error, data } = useDataQuery(transactionRequest)
        if (error) {
         return (error);
        }
      
        if (loading) {
          return (loading);
        }
      
        if (data) {
          console.log("Transaction List :", (data).request0.dataSets);
          return (data).request0.dataSets;
        }
    }

    const dataMutationQuery = {
        resource: 'dataStore/IN5320-G15/transactions',
        type: 'update',
        dataSet: 'dataSets',
        data: {
            dataSets: {
                date: date,
                dispensedBy: dispensedby,
                dispensedTo: recipient,
                transactionType: type,
            }
        }
        }

    const [mutate, {loading, error }] = useDataMutation(dataMutationQuery);

    const transactionList = sendTransactionRequest();

    // const dataMutationQuery = {
    //     resource: 'dataStore/IN5320-G15/transactions',
    //     type: 'update',
    //     dataSet: 'dataSets',
    //     data: ({transactionList, date, dispensedBy, dispensedTo, transactionType}) => ({
    //             dataSets: 
    //                 transactionList.map((e) =>( {
    //                     amount: e.amount,
    //                     commodity: e.commodity,
    //                     date: e.date,
    //                     dispensedBy: e.dispensedBy,
    //                     dispensedTo: e.dispensedTo,
    //                     transactionType: e.transactionType
    //                 })),
    //     }),
    // }
    
        return (
            <span>{mutate({dataMutationQuery: dataMutationQuery})}</span>
        )
}