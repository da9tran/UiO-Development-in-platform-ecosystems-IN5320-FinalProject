import React, { useState } from "react";
import {
    Button,
    Input,
    Table,
    TableHead,
    TableCellHead,
    TableRowHead,
    TableBody,
    TableRow,
    TableCell,
    IconDelete16,
    IconAdd16
  } from "@dhis2/ui";

export function Dropdown(){
    const [val,setVal]=useState('')
    const data=[
        "Female Condom",
        "Implants",
        "Emergency Contraceptions",
        "Oxytocin",
        "Misoprostal",
        "Magnesium Sulfate",
    ]


    return(
        <div className="main">
            <input list="data" onChange={(e)=>setVal(e.target.value)} placeholder="--Commodity--" />
            <datalist id="data">
                {data.map((op)=><option>{op}</option>)}
            </datalist>
        </div>
    );
}
export default Dropdown;