import React from 'react';
import {
    ReactFinalForm,
    InputFieldFF,
    Button,
    SingleSelectFieldFF,
    hasValue,
    number,
    composeValidators,
    Input,
    InputField,
    Table,
    TableHead,
    TableCellHead,
    TableRowHead,
    TableBody,
    TableRow,
    TableCell,
    IconDelete16,
    IconAdd16
} from '@dhis2/ui';

import { useDataMutation } from '@dhis2/app-runtime';
import Droppern from './droppern';
import classes from "./styling/insert.css";
import { useDataQuery } from '@dhis2/app-runtime';
import { useState } from 'react';

// update query that replaces the data within the "transactions" key in our dataStore
const dataMutationQuery = {
    resource: 'dataStore/IN5320-G15/transactions',
    type: 'update',
    dataSet: 'dataSets',
    data: ({transactionList, amount, commodity, date, dispensedBy, dispensedTo, transactionType}) => ({
            dataSets: 
                transactionList.map((e) =>( {
                    amount: e.amount,
                    commodity: e.commodity,
                    date: e.date,
                    dispensedBy: e.dispensedBy,
                    dispensedTo: e.dispensedTo,
                    transactionType: e.transactionType
                })),
    }),
}

export function Insert(props) {
    const [mutate, { loading, error }] = useDataMutation(dataMutationQuery)
    const usercredentials = sendRequest();

    const [{ loadingTransaction, errorTransaction, data }] = useDataMutation(transactionRequest);
    const transactionList = sendTransactionRequest()

    const[transactions, setTransactions] = useState([{commodity: "", amount: ""}]);
    
    // onsubmit for placing the new data into the fetched list from the dataStore database
    function onSubmit(formInput) { 
        // gets date for dispensing
        const current = new Date();
        const date = `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`;

        // create list for all the components
        let comList = setComValueList(formInput);

        const commodityInpValues = splitValue(comList[0]);

        // pushing user-input into a list of transactions
        transactionList.push({
            amount: comList[1],
            commodity:  {id: commodityInpValues[0], name: commodityInpValues[1]},
            date: date,
            dispensedBy: usercredentials,
            dispensedTo: formInput.recipent,
            transactionType: "dispense"
        })

        mutate({
            transactionList: transactionList,
            // amount: formInput.amount,
            // commodity:  {id: formInput.commodity, name: "sample text"},
            // date: 20221114,
            // dispensedBy: usercredentials,
            // dispensedTo: formInput.recipent,
            // transactionType: "dispense"
        })
    }

    return (
        <div className='container'>
            <ReactFinalForm.Form id="dispense-form" onSubmit={onSubmit}>
                {({ handleSubmit }) => (
                    <form onSubmit={handleSubmit} autoComplete="off">
                        <div className='containerCredentials'>
                            <div className='reci'>
                                <ReactFinalForm.Field
                                    name="recipent"
                                    label="Recipent:"
                                    component={InputFieldFF}
                                    className={classes.myInput}
                                    validate={composeValidators(hasValue)}
                                />
                                
                            </div>
                            <div className='disBy'>
                                <ReactFinalForm.Field
                                    disabled
                                    name="dispensedBy"
                                    label="Dispensed by:"
                                    value={usercredentials}
                                    placeholder={usercredentials}
                                    component={InputFieldFF}
                                    //validate={composeValidators(hasValue)}
                                />
                            </div>
                        </div>
                        <br></br>
                        <div className='commodityContainer'>
                            {transactions.map((transaction, index) => (
                                <div key={index} id={index} className='commodityContainerComponent'>
                                    <div className='comLeft'>
                                        <Droppern index={index} transactions={transactions}/>
                                    </div>
                                    <div className='comRight'>
                                        <ReactFinalForm.Field
                                                name={"amount"+index}
                                                label="Amount:"
                                                placeholder="Amount"
                                                component={InputFieldFF}
                                                validate={composeValidators(hasValue, number)}
                                                defaulValue={transaction.amount}
                                                onChange={(e)=>{
                                                    transactions[index].amount = e.value
                                                    console.log("kuk")

                                                }}
                                        />

                                        {/* {getCommodityEndBalance("JIazHXNSnFJ")} */}
                                    </div>

                                    <Button className="deleteBtn" name="Primary button" onClick={()=>{
                                        
                                       
                                        let comElement = document.getElementById(index)
                                        comElement.parentElement.removeChild(comElement)
                                        //setTransactions(tmp2)
                                    }} primary value="default"><IconDelete16/></Button>
                                </div>
                            ))}
                            <br></br>
                            <Button className={classes.addCommodity} name="Primary button" onClick={()=>{
                                const tmp = {
                                    commodity:"",
                                    amount:""
                                }

                                setTransactions([...transactions, tmp])


                            }}secondary value="default"><IconAdd16/> &nbsp;  Add another commodity</Button>
                        </div>
                        <br></br>
                            <Button type="submit" primary>
                            Register transaction
                        </Button>
                    </form>
                )}
            </ReactFinalForm.Form>
        </div>
    )
}

//query to get name
const getName = {
    request0: {
      resource: "/me",
      params: {
        fields: "name"
      }
    }
  }

// gets username from DHIS-webapp
const sendRequest = () => {
    const { loading, error, data } = useDataQuery(getName)
    if (error) {
     return (error);
    }
  
    if (loading) {
      return (loading);
    }
  
    if (data) {
      console.log("Username: ", data);
      return (data).request0.name;
    }
}

// query to get transactionlist
const transactionRequest = {
    request0: {
        resource: "dataStore/IN5320-G15/transactions"
    }
}
// gets list of transactions from our namespace resource
const sendTransactionRequest = () => {
    const { loading, error, data } = useDataQuery(transactionRequest)
    if (error) {
     return (error);
    }
  
    if (loading) {
      return (loading);
    }
  
    if (data) {
      console.log("Transaction List :", (data).request0.dataSets);
      return (data).request0.dataSets;
    }
}

function splitValue (value) {
    let processed = value.split("-")
    //console.log(processed)
    return processed
}

function setComValueList(formInput) {
    console.log(formInput.commodity0, formInput.amount0);
    
    // console.log(formInput.commodity0, formInput.amount0);
    console.log(formInput)

    let commodity = []
    let amount = []
    
    for (let i = -1; i < formInput.length/2; i++) {
        amount.push([formInput[i]]);
    }

    // for (let i = 2; i < formInput.length; i++) {
    //     commodity.push([formInput[i]]);
        
    // }

    console.log(amount)
    return [formInput.commodity0, formInput.amount0]
}

// query for end balance and consumption of commodities from orgunit komba
const fetchEndBalance = {
    request0: {
        resource: "/dataValueSets",
        params: {
        orgUnit: "T62lSjsZe9n",
        period: "202110",
        dataSet: "ULowA8V3ucd",
        fields: "dataValues"
        }
    }
}

// consumptiom: J2Qf1jtZuj8
// endbalance: rQLFnNXXIL0


//function for fetching end balance for given commodity in the period "202111"
function fetchCommodityBalance(commodityID) {
    let endBalanceArray = [];
    
    const { loading, error, data } = useDataQuery(fetchEndBalance);

    if (error) {
      return <span>ERROR: {error.message}</span>;
    }
  
    if (loading) {
      return <span>Loading...</span>;
    }
  
    if (data) {
        data.request0.dataValues.forEach(element => {
            //console.log(element.categoryOptionCombo);
            if (element.categoryOptionCombo == "rQLFnNXXIL0") {
                endBalanceArray.push({
                    "balance" : element.value,
                    "id" : element.dataElement,
                })
            };
        });

        console.log(endBalanceArray);
        console.log(endBalanceArray[0].id);

        let chosenEndBalance = {};

        endBalanceArray.forEach(element => {
            if (element.id == commodityID) {
                chosenEndBalance = {
                    "balance" : element.balance,
                    "id" : element.id,
                }
            }
        });


        //console.log("data: ", mergedData[0].dataValues)
        return chosenEndBalance.balance;
    }
};

function getComBalance() {
    console.log(fetchCommodityBalance("d9vZ3HOlzAd"));
}