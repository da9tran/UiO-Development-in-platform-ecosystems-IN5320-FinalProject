import React, { useState } from "react";
import classes from "../App.module.css";
import { StockRegisterTableRow } from "./StockRegisterTableRow";
import {
  Table,
  Button,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  TableRowHead,
  TableCellHead,
  Input,
  DropdownButton,
  IconAdd16,
} from "@dhis2/ui";

let dataToBeSent = []; // collects data from the different rows 

function getDataFromTable(id, commodity, amount) { // collects, pushes and replaces data from each table row
  let index = dataToBeSent.findIndex((obj => obj.id == id));

  if (index !== -1) {
    dataToBeSent[index] = {
      "id" : id,
      "amount" : amount,
      "commodity" : commodity
    }
  }else {
    let newData = {
      "id" :  id,
      "amount" : amount,
      "commodity" : commodity
    }
    dataToBeSent.push(newData);
  }
}

let rowList  = []

export function StockRegisterTable(props) { 
  const [rows, setRows] = useState({id: 0});

  return (
    <Table className={classes.stockRecountTable}>
      <TableHead className={classes.greyHead}>
        <TableRowHead>
          <TableCellHead className={classes.recountTableCommodity}>Commodity</TableCellHead>
          <TableCellHead className={classes.recountTableStock}>New delivery stock amount</TableCellHead>
        </TableRowHead>
      </TableHead>
      <TableBody>
      {rowList.map((row) => <StockRegisterTableRow id={rowList[row.id].id} commodityData={props.commodityData} getData={getDataFromTable} dataSend={props.dataSend} dataToBeSent={dataToBeSent}/>)}
          <TableCell>
            <Button style="margin:4px;" name="Add commodity" onClick={() => {{setRows({id:(rowList.length+1)})} {rowList.push(rows)} } } secondary value="default"><IconAdd16/> &nbsp; Add commodity</Button>
          </TableCell>
      </TableBody>
    </Table>
  );
}