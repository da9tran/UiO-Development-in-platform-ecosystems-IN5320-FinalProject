import React from "react";
import classes from "../App.module.css";
import { 
    Table,
    TableRow,
    TableBody,
    TableCell,
    TableHead,
    TableRowHead,
    TableCellHead,
   } from '@dhis2/ui'

export function StockoverviewTable(props) {
    return (
        <Table className={classes.stockoverviewTable}>
            <TableHead className={classes.greyHead}>
                <TableRowHead>
                    <TableCellHead className={classes.stockoverviewTableCommodity}>
                        Commodity
                    </TableCellHead>
                    <TableCellHead className={classes.stockoverviewTableStock}>
                        Stock
                    </TableCellHead>
                </TableRowHead>
            </TableHead>
            <TableBody>
            {(props.getData).map((element) => (
                <TableRow>
                    <TableCell>{(element.name)}</TableCell>
                    <TableCell>{element.endbalance}</TableCell>
                </TableRow>
            ))}
            </TableBody>
        </Table>
    );
}