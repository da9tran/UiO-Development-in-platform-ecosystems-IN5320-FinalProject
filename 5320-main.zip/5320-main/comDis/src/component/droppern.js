import React from "react";
import { useDataQuery } from "@dhis2/app-runtime";
import { Menu } from "@dhis2/ui";
import { MenuItem } from "@dhis2/ui";
import { useState } from "react";
import classes from "../App.module.css"
import {
  Table,
  TableBody,
  TableCell,
  TableCellHead,
  TableFoot,
  TableHead,
  TableRow,
  TableRowHead,
} from "@dhis2/ui";
import {
    ReactFinalForm,
    InputFieldFF,
    Button,
    SingleSelectFieldFF,
    SingleSelect,
    SingleSelectOption,
    hasValue,
    number,
    composeValidators,
} from '@dhis2/ui'

function mergeData(data) {
  let mergedData = data.dataSetElements.dataSetElements.map((element) => {
    return {
      displayName: element.dataElement["name"],
      id: element.dataElement["id"],
    };
  });
  // console.log("Mergedata:", mergeData);

  return mergedData;
}

// query for getting the different commodity names and id
const dataQuery = {
  dataSetElements: {
    resource: "dataSets/ULowA8V3ucd?fields=dataSetElements[dataElement[name,id]]",
    params: {
      fields: "dataElement[name, id]",
    },
  },
};

export function Droppern(props) {
  const [tableElement, setTableElement] = useState();

  const { loading, error, data } = useDataQuery(dataQuery);
  if (error) {
    return <span>ERROR: {error.message}</span>;
  }

  if (loading) {
    return <span>Loading...</span>;
  }

  if (data) {
    //console.log("API response:", data);
    let mergedData = mergeData(data);

    return (
      <div>
          <ReactFinalForm.Field
              component={SingleSelectFieldFF}
              name={"commodity"+props.index}
              label="Commodity:"
              initialValue=""
              placeholder="Select a commodity"
              options={
                  mergedData.map((e)=>(
                      {
                          label: splitName(e.displayName),
                          value: e.id+"-"+splitName(e.displayName),
                      })
                  )
              }
              validate={composeValidators(hasValue)}
              //onChange={(e=>{console.log("Droppern instance: "+e)})}
          />
          
      </div>
    );
  }
}

function splitName (name) {
    let processed = name.split(" - ")
    //console.log(processed)
    return processed[1]
}

export default Droppern;

