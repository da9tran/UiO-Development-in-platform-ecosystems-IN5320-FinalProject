import React from 'react'
import { useDataQuery } from '@dhis2/app-runtime'
import { useDataMutation } from '@dhis2/app-runtime'
import classes from "./App.module.css"
import { StockoverviewTable } from "./component/StockoverviewTable"
import { StockRecountTable } from "./component/StockRecountTable"
import { StockRegisterTable } from './component/StockRegisterTable'
import { allData } from './StockOverview'
import { 
    Button,
    Input,
    IconArrowLeft24,
    IconSave24
   } from '@dhis2/ui'


// let orgunit = "T62lSjsZe9n";
// let periode = "202110";
// let dataSet = "ULowA8V3ucd"
// let femalecondom = "dY4OCwl0Y7Y"

let collectedArray = [];

function collectData(array){ // gets data from the table which then is passed to dataToBeSubmitted
    collectedArray = array;
    dataToBeSubmitted();
}

// const commoditiesQuery = {
//     dataSetElements: {
//       resource: "dataSets/ULowA8V3ucd?fields=dataSetElements[dataElement[name,id]]",
//       params: {
//         fields: "dataElement[name, id]",
//       },
//     },
// };

// En funksjon som endrer end balance for ID 

function dataToBeSubmitted(){
    let mergedData = [...allData]; // clones the allData array

    collectedArray.forEach(element => {
        let id = element.commodity;
        let amount = element.amount;


        mergedData.forEach(element2 => {
            if (element2.id == id){

                let indexOfCurrentAmount = allData.findIndex(element => element.id == id);
                let oldAmount = (allData[indexOfCurrentAmount].endbalance);

                let newconsumption;

                if (oldAmount > amount){
                    newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) + parseInt(oldAmount - amount);
                }else if (oldAmount < amount){
                    newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) - parseInt(amount - oldAmount);
                }else if (oldAmount == amount){
                    newconsumption = parseInt(allData[indexOfCurrentAmount].consumption);
                }

                let index = mergedData.findIndex(element3 => element3.id == id);

                mergedData[index] = {
                    "id" : mergedData[index].id,
                    "name" : mergedData[index].name,
                    "consumption" : newconsumption.toString(),
                    "endbalance" : amount,
                }
             }
        })
    })
    return mergedData;
}

function jsonObjectCreator(){
    let formattedData = [];

    dataToBeSubmitted().forEach(element => {
        let object = {
            "dataElement" : element.id,
            "categoryOptionCombo":
            "rQLFnNXXIL0", 
            "value": element.endbalance,
        }
        formattedData.push(object);
    })


    return {
                        "dataSet": "ULowA8V3ucd",
                        "resource":"dataValueSets",
                        "completeDate": "2021-11-04", // oppdater til dagens dato
                        "type": "create", 
                        "data": {
                           "orgUnit": "T62lSjsZe9n", // org unit burde hentes fra api egentlig!
                           "period": "202110", // oppdater med dagens dato
                           "dataValues": formattedData}
        }
}

export function StockRegister(props){
    let jsonobject = jsonObjectCreator();
    console.log(jsonobject);
    
    const [mutate, { loading, error }] = useDataMutation(jsonobject);
    const sendRequest = () => {
        if(loading){
            return "Submitting data...";
        }if(error){
            return ("Error when submitting data:", error.message);
        }if(mutate){
            return "Successfully submitted recount";
        }else {
            return "Submitting...";
        }
    }


    return(   
    <div className={classes.stockRecountMain}>
      <div className={classes.title}>
          <h1>Stock registry</h1>
          <p>Register new stock of life-saving commodities by filling out the fields below</p>
      </div>
      <div className={classes.recountNavButton}>
          <Button name="Secondary button" onClick={() => {props.changePage("stockoverview")}} secondary value="default"><IconArrowLeft24 /> &nbsp; Go back to stock overview</Button>
      </div>

      <div className={classes.recountTableDiv}>
          <StockRegisterTable commodityData={props.commodityData} dataSend={collectData}/>
      </div>

      <div className={classes.recountSendButton}>
          <Button name="Primary button" onClick={() =>{
              {mutate({jsonobject: jsonobject})}
              {alert("New stock registered")}
              }} primary value="default"><IconSave24/> &nbsp; Register stock delivery</Button>
      </div>
    </div>
    )
}


// import React from 'react'
// import { useDataMutation } from '@dhis2/app-runtime'
// import classes from "./App.module.css"
// import { StockRegisterTable } from './component/StockRegisterTable'
// import { allData } from './StockOverview'
// import { TransactionCreator } from './component/CreateTransaction'
// import { 
//     Button,
//     Input,
//     IconArrowLeft24,
//     IconSave24
//    } from '@dhis2/ui'
// import { TransactionCreator } from './component/TransactionCreator'

// let collectedArray = [];

// function collectData(array){ // gets data from the table which then is passed to dataToBeSubmitted
//     collectedArray = array;
//     dataToBeSubmitted();
// }


// function dataToBeSubmitted(){
//     let mergedData = [...allData]; // clones the allData array

//     collectedArray.forEach(element => {
//         let id = element.commodity;
//         let amount = element.amount;


//         mergedData.forEach(element2 => {
//             if (element2.id == id){

//                 let indexOfCurrentAmount = allData.findIndex(element => element.id == id);
//                 let oldAmount = (allData[indexOfCurrentAmount].endbalance);

//                 let newconsumption;

//                 if (oldAmount > amount){
//                     newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) + parseInt(oldAmount - amount);
//                 }else if (oldAmount < amount){
//                     newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) - parseInt(amount - oldAmount);
//                 }else if (oldAmount == amount){
//                     newconsumption = parseInt(allData[indexOfCurrentAmount].consumption);
//                 }

//                 let index = mergedData.findIndex(element3 => element3.id == id);

//                 mergedData[index] = {
//                     "id" : mergedData[index].id,
//                     "name" : mergedData[index].name,
//                     "consumption" : newconsumption.toString(),
//                     "endbalance" : amount,
//                 }
//              }
//         })
//     })
//     return mergedData;
// }

// function jsonObjectCreator(){
//     let formattedData = [];

//     dataToBeSubmitted().forEach(element => {
//         let object = {
//             "dataElement" : element.id,
//             "categoryOptionCombo":
//             "rQLFnNXXIL0", 
//             "value": element.endbalance,
//         }
//         formattedData.push(object);
//     })


//     return {
//                         "dataSet": "ULowA8V3ucd",
//                         "resource":"dataValueSets",
//                         "completeDate": "2021-11-04", // oppdater til dagens dato
//                         "type": "create", 
//                         "data": {
//                            "orgUnit": "T62lSjsZe9n", // org unit burde hentes fra api egentlig!
//                            "period": "202110", // oppdater med dagens dato
//                            "dataValues": formattedData}
//         }
// }

// export function StockRegister(props){
//     let jsonobject = jsonObjectCreator(); // THERE IS SOMETHIG WRONG WITH THE PLACEMENT OF THIS, IT IS CREATED TOO EARLY
//     // BUT WE CANNOT FOR THE LIFE OF US FIGURE OUT HOW TO SOLVE THIS. THEREFORE THE MUTATE SENDS OLD DATA, AND NOT NEW. 
//     // ENDING WITH IT NOT UPDATING ANY BALANCES OR CONSUMPTION.
//     console.log(jsonobject);
    
//     const [mutate, { loading, error }] = useDataMutation(jsonobject);
//     const sendRequest = () => {
//         if(loading){
//             return "Submitting data...";
//         }if(error){
//             return ("Error when submitting data:", error.message);
//         }if(mutate){
//             return "Successfully submitted recount";
//         }else {
//             return "Submitting...";
//         }
//     }


//     return(   
//     <div className={classes.stockRecountMain}>
//       <div className={classes.title}>
//           <h1>Stock registry</h1>
//           <p>Register new stock of life-saving commodities by filling out the fields below</p>
//       </div>
//       <div className={classes.recountNavButton}>
//           <Button name="Secondary button" onClick={() => {props.changePage("stockoverview")}} secondary value="default"><IconArrowLeft24 /> &nbsp; Go back to stock overview</Button>
//       </div>

//       <div className={classes.recountTableDiv}>
//           <StockRegisterTable commodityData={props.commodityData} dataSend={collectData}/>
//       </div>

//       <div className={classes.recountSendButton}>
//           <Button name="Primary button" onClick={() =>{
//             // <TransactionCreator dispensedBy="Kristian", recipient="Mr. Smith", date="18/11/2022", type="Stock registry"/>
//               {mutate({jsonobject: jsonobject})} 
//               {alert("New stock registered")}
//               }} primary value="default"><IconSave24/> &nbsp; Register stock delivery</Button>
//       </div>
//     </div>
//     )
// }

// // legge til transaction opprettelse etter merge
