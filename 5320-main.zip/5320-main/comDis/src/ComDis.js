import React from "react";
import classes from "./App.module.css";
import {
 
} from "@dhis2/ui";
import { Insert } from "./component/insert";


const getName = {
  request0: {
    resource: "/me",
    params: {
      fields: "name"
    }
  }
}

export function ComDis() {
  return (
    <div>
    <div className={classes.title}>
    <h1>Commodity dispensing</h1>
    <p>Complete a commodity transaction by filling out the fields below.</p>
    </div>
    <Insert/>
    </div>
  );
}
