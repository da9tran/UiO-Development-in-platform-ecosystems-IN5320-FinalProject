import React from "react";
import classes from "./App.module.css";
import { useState } from "react";

import { ComDis } from "./ComDis";
import { Navigation } from "./Navigation";
import { TransactionHistory } from "./TransactionHistory";
import { StockOverview } from "./StockOverview";

function MyApp() {
  const [activePage, setActivePage] = useState("ComDis");

  function activePageHandler(page) {
    setActivePage(page);
  }

  return (
    <div className={classes.container}>
      <div className={classes.left}>
        <Navigation
          activePage={activePage}
          activePageHandler={activePageHandler}
        />
      </div>
      <div className={classes.right}>
        {activePage === "ComDis" && <ComDis />}
        {activePage === "StockOverview" && <StockOverview/>}
        {activePage === "TransactionHistory" && <TransactionHistory/>}
      </div>
    </div>
  );
}

export default MyApp;