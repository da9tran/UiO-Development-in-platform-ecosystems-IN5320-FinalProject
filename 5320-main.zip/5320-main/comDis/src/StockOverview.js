import React, { useState } from 'react'
import classes from "./App.module.css"
import { StockoverviewTable } from "./component/StockoverviewTable"
import { useDataQuery } from "@dhis2/app-runtime";
import { StockRegister } from "./StockRegister"
import { StockRecount } from "./StockRecount"
import { 
    Button,
    Input,
   } from '@dhis2/ui'
import { TransactionCreator } from './component/TransactionCreator';

const requestCommodityInfo = { 
    request: {
        resource: "/dataSets/ULowA8V3ucd",
        params: {fields: "dataSetElements[dataElement[name,id]"},
    }
}

const requestCommodityBalanceAndConsumption = {
    request0: {
      resource: "/dataValueSets",
      params: {
        orgUnit: "T62lSjsZe9n",
        period: "202110",
        dataSet: "ULowA8V3ucd",
        fields: "dataValues"
      }
    }
}
let dataArray = []; // stores name and id
let consumptionArray = []; // stores consumption and id
let endbalanceArray = []; // stores endbalance and id
export let allData = []; // merged data from the arrays below into one array: id, name, consumption, endbalance

function merge(){ // merges data from the three separate arrays into one commodity object, which is then added to allData array
    (dataArray).forEach(element => {
        let id = element.dataElement.id;
        let name = element.dataElement.name;
        let consumption;
        let endbalance;
        consumptionArray.forEach(element2 => {
            if(element2[0].id == id){
                consumption = element2[0].consumption;
            }
        })
        endbalanceArray.forEach(element3 => {
            if(element3[0].id == id){
                endbalance = element3[0].endbalance;
            }
        })
        let mergedElement = {
            "id" : id,
            "name" : name.substring(14),
            "consumption" : consumption,
            "endbalance" : endbalance,
        }
        if(allData.length < dataArray.length){
            allData.push(mergedElement);
        }
    }
    )
}

export function StockOverview() {
    const [page, setPage] = useState("stockoverview");

    const sendRequest = () => { // gets name and id of commodities, the request is placed here because it should be updated on state change, like when a user comes back from a completed recount or register session
        const { loading, error, data } = useDataQuery(requestCommodityInfo);
        if(error){return <span>{error.message}</span>}
        if(loading){return <span>Loading stock data...</span>}
        if(data){
            if (dataArray.length == 0){
                (data.request.dataSetElements).forEach(element => dataArray.push(element));
            }
        }
    }

    const sendRequest2 = () => { // gets consumption and end balance of commodities
        const { loading, error, data } = useDataQuery(requestCommodityBalanceAndConsumption);
        if(error){return <span>{error.message}</span>}
        if(loading){return <span>Loading stock data...</span>}
        if(data){
            if ((consumptionArray.length == 0) && (endbalanceArray.length == 0)){
                (data.request0.dataValues).forEach(element => {
                    if (element.categoryOptionCombo == "J2Qf1jtZuj8"){
                        let object = [{
                            "id" : element.dataElement,
                            "consumption" : element.value,
                        }]
                        consumptionArray.push(object);
                    }else if (element.categoryOptionCombo == "rQLFnNXXIL0"){
                        let object = [{
                            "id" : element.dataElement,
                            "endbalance" : element.value,
                        }]
                        endbalanceArray.push(object);
                    }
                } 
                );
            }
        }
    }
    sendRequest();
    sendRequest2();
    merge();

    switch(page){ // changes the page state so that either overview, recount og register page is shown on button clicks
        case("recount"):
            return (<StockRecount commodityData={allData} changePage={setPage}/>);
            break;
        case("register"):
            return (<StockRegister commodityData={allData} changePage={setPage} />);
            break;
        case("stockoverview"):
            return (
                <div className={classes.stockoverviewMain}>
                    <div className={classes.title}>
                        <h1>Commodity stock overview</h1>
                        <p>Get an overview of your current stock and perform stock recounts</p>
                    </div>
    
                    <div className={classes.stockoverviewButtons}>
                        <Button name="Primary button" onClick={() => { setPage("register")} } primary value="default">Register delivered stock</Button>
                        <Button name="Primary button" onClick={() => { setPage("recount") }} primary value="default">Perform stock recount</Button>
                        <Button name="Secondary button" onClick={""} secondary value="default">Export to PDF</Button>
                    </div>
    
                    <div className={classes.stockoverviewSearchbar}>
                        <Input name="searchbars" /* onChange={} */ placeholder="Search..." />
                    </div>
    
                    <div className={classes.stockoverviewTable}>
                        <StockoverviewTable getData={allData}/>
                    </div>
                </div>
            ) 
            break;
    }
}