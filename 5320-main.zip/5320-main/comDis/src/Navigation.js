import React from "react";
import { Menu, MenuItem } from "@dhis2/ui";

export function Navigation(props) {
  return (
    <Menu>
      <MenuItem
        label="Commodity dispensing"
        active={props.activePage == "ComDis"}
        onClick={() => props.activePageHandler("ComDis")}
      />
      <MenuItem
        label="Stock overview"
        active={props.activePage == "StockOverview"}
        onClick={() => props.activePageHandler("StockOverview")}
      />
      <MenuItem
        label="Transaction history"
        active={props.activePage == "TransactionHistory"}
        onClick={() => props.activePageHandler("TransactionHistory")}
      />
    </Menu>
  );
}