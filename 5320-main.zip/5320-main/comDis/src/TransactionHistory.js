import React from 'react'
import classes from "./App.module.css"
import { TransactionHistoryTable } from './component/TransactionHistoryTable'

export function TransactionHistory(){
    return (
        <div>
            <div className={classes.title}>
                <h1>Transaction history</h1>
                <p>Latest commodity dispensing, registered new stock and stock recounts</p>
            </div>
            <TransactionHistoryTable/>
        </div>
    );
} 
