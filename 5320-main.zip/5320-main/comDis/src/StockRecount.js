
    // return {    
    //                     "dataSet": "ULowA8V3ucd",
    //                     "resource":"dataValueSets",
    //                     "completeDate": "2021-11-04", // oppdater til dagens dato
    //                     "type": "create", 
    //                     "data": {
    //                         "orgUnit": "T62lSjsZe9n", 
    //                         "period": "202110",
    //                         "dataValues": [
    //                             {
    //                                 dataElement: "JIazHXNSnFJ", 
    //                                 categoryOptionCombo: "rQLFnNXXIL0", 
    //                                 value: "124" 
    //                             },
    //                             {
    //                                 dataElement: "d9vZ3HOlzAd", 
    //                                 categoryOptionCombo: "rQLFnNXXIL0", 
    //                                 value: "124"
    //                             },
    //                             {
    //                                 dataElement: "Boy3QwztgeZ", 
    //                                 categoryOptionCombo: "rQLFnNXXIL0", 
    //                                 value: "124"
    //                             },
    //                             {
    //                                 dataElement: "Lz8MM2Y9DNh", 
    //                                 categoryOptionCombo: "rQLFnNXXIL0", 
    //                                 value: "124"
    //                             },
    //                         ]
    //                     }
    // }

    import React from 'react'
    import { useDataQuery } from '@dhis2/app-runtime'
    import { useDataMutation } from '@dhis2/app-runtime'
    import classes from "./App.module.css"
    import { StockoverviewTable } from "./component/StockoverviewTable"
    import { StockRecountTable } from "./component/StockRecountTable"
    import { StockRegisterTable } from './component/StockRegisterTable'
    import { allData } from './StockOverview'
    import { 
        Button,
        Input,
        IconArrowLeft24,
        IconSave24
       } from '@dhis2/ui'
    
    let collectedArray = [];
    
    function collectData(array){ // gets data from the table which then is passed to dataToBeSubmitted
        collectedArray = array;
        dataToBeSubmitted();
    }
    
    
    function dataToBeSubmitted(){
        let mergedData = [...allData]; // clones the allData array
    
        collectedArray.forEach(element => {
            let id = element.commodity;
            let amount = element.amount;
    
    
            mergedData.forEach(element2 => {
                if (element2.id == id){
    
                    let indexOfCurrentAmount = allData.findIndex(element => element.id == id);
                    let oldAmount = (allData[indexOfCurrentAmount].endbalance);
    
                    let newconsumption;
    
                    if (oldAmount > amount){
                        newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) + parseInt(oldAmount - amount);
                    }else if (oldAmount < amount){
                        newconsumption = parseInt(allData[indexOfCurrentAmount].consumption) - parseInt(amount - oldAmount);
                    }else if (oldAmount == amount){
                        newconsumption = parseInt(allData[indexOfCurrentAmount].consumption);
                    }
    
                    let index = mergedData.findIndex(element3 => element3.id == id);
    
                    mergedData[index] = {
                        "id" : mergedData[index].id,
                        "name" : mergedData[index].name,
                        "consumption" : newconsumption.toString(),
                        "endbalance" : amount,
                    }
                 }
            })
        })
        return mergedData;
    }
    
    function testmutationtry(){
        let formattedData = [];
    
        dataToBeSubmitted().forEach(element => {
            let object = {
                "dataElement" : element.id,
                "categoryOptionCombo":
                "rQLFnNXXIL0", 
                "value": (element.endbalance).toString(),
            }
            formattedData.push(object);
        })
        
        let tmp = []
        for(let i = 0; i < formattedData.length; i++){
            tmp.push(
                {
                    dataElement: formattedData[i].dataElement, 
                    categoryOptionCombo: formattedData[i].categoryOptionCombo, 
                    value: formattedData[i].value,
                }
            )
        }
    
        return tmp
    }
    
    function jsonObjectCreator(){
        let formattedData = [];
    
        dataToBeSubmitted().forEach(element => {
            let object = {
                "dataElement" : element.id,
                "categoryOptionCombo":
                "rQLFnNXXIL0", 
                "value": (element.endbalance).toString(),
            }
            formattedData.push(object);
        })
        
        let tmp = []
        for(let i = 0; i < formattedData.length; i++){
            tmp.push(
                {
                    orgUnit: "T62lSjsZe9n", 
                    period: "202110",
                    dataElement: formattedData[i].dataElement, 
                    categoryOptionCombo: formattedData[i].categoryOptionCombo, 
                    value: formattedData[i].value,
                }
            )
        }
    
        // [
        //     forma.map((e)=>(
        //         {
        //             dataElement: ,
        //             categoryOptionCombo: ,
        //             value: ,
        //         })
        //     )
        // ]
    
        // gets date for changes
        const current = new Date();
        const date = `${current.getDate()}-${current.getMonth()+1}-${current.getFullYear()}`;
    
        return {    
            "dataSet": "ULowA8V3ucd",
            "resource":"dataValueSets",
            "completeDate": date, // updating date
            "type": "create", 
            "data": {
                "orgUnit": "T62lSjsZe9n", 
                "period": "202110", // we base our data on this period "2021/10"
                "dataValues": tmp,
            }
        }
    }
    
    export function StockRecount(props){
        // gets date for changes
        const current = new Date();
        const date = `${current.getDate()}-${current.getMonth()+1}-${current.getFullYear()}`;
        let jsondata = [];
    
        let testmutate = {    
            
            //"orgUnit": "T62lSjsZe9n", 
            //"period": "202110", // we base our data on this period "2021/10"
            // "data": ({ orgUnit, period, dataElement, categoryOptionCombo, value }) => ({
            //     "dataValues":[{
            //         orgUnit: orgUnit,
            //         period: period,
            //         dataElement: dataElement, 
            //         categoryOptionCombo: categoryOptionCombo, 
            //         value: value,
            //     }]
            // })
            "resource":"dataValueSets",
            "type": "create",
            "dataSet": "ULowA8V3ucd",
            "completeDate": date, // updating date
            "data": ({ dataElement, categoryOptionCombo, value }) => ({
                "orgUnit": "T62lSjsZe9n", 
                "period": "202110", // we base our data on this period "2021/10"
                "dataValues": [
                    {
                        dataElement: dataElement, 
                        categoryOptionCombo: categoryOptionCombo, 
                        value: value,
                    }
                ],
            })
    
        }
        
        
        //const [mutate, { mutateLoading, mutateError }] = useDataMutation(jsonObjectCreator());
        const [mutate, { mutateLoading, mutateError }] = useDataMutation(testmutate);
    
        return(   
        <div className={classes.stockRecountMain}>
          <div className={classes.title}>
              <h1>Stock recount</h1>
              <p>Perform a recount of your current commodity stock by filling out the fields below</p>
          </div>
          <div className={classes.recountNavButton}>
              <Button name="Secondary button" onClick={() => {props.changePage("stockoverview")}} secondary value="default"><IconArrowLeft24 /> &nbsp; Go back to stock overview</Button>
          </div>
    
          <div className={classes.recountTableDiv}>
              <StockRecountTable commodityData={props.commodityData} dataSend={collectData}/>
          </div>
    
          <div className={classes.recountSendButton}>
              <Button name="Primary button" onClick={() =>{
                    //{mutate(jsonobject => jsonobject)}}
                    const current = new Date();
                    const date = `${current.getDate()}-${current.getMonth()+1}-${current.getFullYear()}`;
    
                    // let test = {    
                    //     "dataSet": "ULowA8V3ucd",
                    //     "resource":"dataValueSets",
                    //     "completeDate": date, // updating date
                    //     "type": "create",
                    //     "data": {
                    //         "orgUnit": "T62lSjsZe9n", 
                    //         "period": "202110", // we base our data on this period "2021/10"
                    //         "dataValues": testmutationtry(),
                    //     }
                    // }
    
                    
    
                    
                    //{mutate({orgUnit: "T62lSjsZe9n", period: "202110", dataElement: "", categoryOptionCombo: "", value: ""})}
                    let test = testmutationtry()
                    //console.log("Commodity:", test[0])
                    console.log(test.length)
                    for(let i = 0; i < test.length; i++) {
                        {mutate({
                            dataElement: test[i].dataElement,
                            categoryOptionCombo: test[i].categoryOptionCombo,
                            value: test[i].value,
                        })}
                    }
                    

                    // let test = testmutationtry() 
                    //     for(let i = 0; i < test.length; 0++){
                    //         console.log("Commodity:", test[i])
                    //         {mutate({
                    //             dataElement: test[i].dataElement,
                    //             categoryOptionCombo: test[i].categoryOptionCombo,
                    //             value: test[i].value,
                    //         })
                    //         }
                    //     }
                    
                    
                    // {mutate({
                        
                        
                    //     dataValues: testmutationtry()})
                    
                    // }
    
                    // { while(mutateLoading){
    
                    // }}
    
                    // {console.log("Error:", mutateError)}
                
                    }
                } primary value="default"><IconSave24/> &nbsp; Register recount</Button>
          </div>
        </div>
        )
    }
    
    
    // const [mutate, { mutateLoading, mutateError }] = useDataMutation(
    //     fetchCommodityMutationQuery()
    // );
    
    // mutate({
    //     lifeCommodityMutation: lifeCommodityMutation,
    // })
    
    // export function fetchCommodityMutationQuery() {
    //     return {
    //         resource: "dataValueSets",
    //         type: "create",
    //         dataSet: "ULowA8V3ucd",
    //         data: ({ lifeCommodityMutation }) => ({
    //             dataValues: lifeCommodityMutation,
    //         }),
    //     };
    //   }
    
    